#' Example output of generative.prob() for use in the vignette/examples
#'
#' @name step1
#' @format A list with 5 elements
NULL

#' Example output of reduce.space() for use in the vignette/examples
#'
#' @name step2
#' @format A list with 6 elements
NULL

#' Example output of parallel.temper() for use in the vignette/examples
#'
#' @name step3
#' @format A list with 2 elements
NULL

